﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASP.NET_数据库_Developer_Test.Properties
{
    public partial class AccessDB : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection(AccessDataSource1.ConnectionString); //Jet OLEDB:Database Password=
            OleDbCommand cmd = conn.CreateCommand();

            cmd.CommandText = string.Format("INSERT INTO test (姓名,任职公司,职务,简介) VALUES('{0}', '{1}', '{2}','{3}')",TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text);
            conn.Open();
            var raw = cmd.ExecuteReader();
            cmd.Dispose();
            conn.Close();
            Response.Redirect(Request.Url.ToString());
        }
    }
}